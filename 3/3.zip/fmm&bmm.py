import traceback

def get_segment_right(text, word_list):
    if text in word_list:
        return text
    elif len(text) == 0:
        return ""
    elif len(text) == 1:
        return text
    else:
        length = len(text) - 1
        text = text[:length]
        return get_segment_right(text, word_list)

def get_segment_left(text, word_list):
    if text in word_list:
        return text
    elif len(text) == 0:
        return ""
    elif len(text) == 1:
        return text
    else:
        length = len(text) - 1
        text = text[-length:]
        return get_segment_left(text, word_list)

def fmm(str):
    word_set = get_word_dict()
    test_str = str.strip()
    result_str = ''
    max_length = 5
    result_length = 0

    while test_str:
        temp = test_str[:max_length]
        seg_str = get_segment_right(temp, word_set)
        seg_length = len(seg_str)

        result_length = result_length + seg_length
        if seg_str.strip():
            result_str = result_str + seg_str + '/'
        test_str = test_str[seg_length:]

    print(result_str)

def bmm(str):
    word_set = get_word_dict()
    test_str = str.strip()
    result_str = ''
    max_length = 5
    result_length = 0

    while test_str:
        temp = test_str[-max_length:]
        seg_str = get_segment_left(temp, word_set)
        seg_length = len(seg_str)

        result_length = result_length + seg_length
        if seg_str.strip():
            result_str = '/' + seg_str + result_str
        test_str = test_str[:-seg_length]

    print(result_str)

def get_word_dict():
    words_set = list()
    with open("./wordcount.txt", encoding="utf-8") as f:
        line = f.readline()
        while line:
            word = line.split(":")
            try:
                words_set.append(word[0])
            except:
                print(traceback)
            line = f.readline()
    f.close()
    return words_set

if __name__ == '__main__':
    test_str = '祝愿祖国明天更加繁荣昌盛 香港大学生在京度佳节'
    bmm('祝愿祖国明天更加繁荣昌盛 香港大学生在京度佳节')